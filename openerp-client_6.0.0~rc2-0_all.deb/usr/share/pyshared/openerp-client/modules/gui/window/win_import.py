# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import gtk
from gtk import glade
import gobject
import gettext
import common

import rpc

import csv
import cStringIO

import options
import service

import threading
import time

import_block = 100
class import_worker(threading.Thread):
    def __init__(self, datas, import_block, model, f, upd_keys, context=None,
            o2m_fields=False):
        super(import_worker, self).__init__()
        if not o2m_fields:
            o2m_fields = []
        self.close = threading.Event()
        self.finished = threading.Event()
        self.ldata = len(datas)
        self.datas = datas
        self.lblock = import_block
        self.limported = 0
        self.errors = []
        self.exception = None
        self.model = model
        self.f = f
        self.o2m = o2m_fields
        self.upd_keys = upd_keys
        self.context = context

    def check_slice(self, rows, start, size):
        if not len(self.o2m) > 0 or len(rows) <= start+size+1:
            return size
        if not rows[start+size+1][0]:
            return self.check_slice(rows, start, size+1)
        return size

    def run(self):
        def go(rows, start, osize):
            size = self.check_slice(rows, start, osize)
            while len(rows[start:start+size]) and not self.close.isSet():
                cslice = rows[start:start+size]
                try:
                    res = rpc.session.rpc_exec_auth('/object', 'execute',
                            self.model, 'import_data', self.f, cslice,
                            'init', '', False, self.context, False,
                            self.upd_keys)
                except Exception, e:
                    exc = str(e)
                    return False
                if res[0] >= 0:
                    self.limported += res[0]
                elif size > 1:
                    nsize = int(size / 2)
                    if nsize == 0:
                        nsize = 1
                    csize = self.check_slice(rows, start, nsize)
                    if csize == size:
                        self.errors.append((cslice[0], res[2], res[3]))
                        return False
                    res = go(cslice, 0, nsize)
                    if not res:
                        return False
                elif size == 1:
                    self.errors.append((cslice[0], res[2], res[3]))
                start += size
                size = self.check_slice(rows, start, osize)
            return True
        res = False
        try:
            res = go(self.datas, 0, self.lblock)
            return res
        finally:
            self.finished.set()

def stop_import_worker(wdget, evt, worker):
    worker.close.set()
    return False

def gen_progress_callback(pg_win, res_win, csv_data, pb):
    def progress_callback(worker):
        gtk.gdk.threads_enter()
        length = ((float(worker.limported) + len(worker.errors)) /
                float(worker.ldata))
        try:
            if worker.finished.isSet():
                pg_win.hide_all()
                common.message(('Se importaron %d registros'
                        '(%d registros producieron errores)') %
                        (worker.limported, len(worker.errors)))
                if worker.errors:
                    resp = res_win.run()
                    if resp == gtk.RESPONSE_OK:
                        fname = res_win.get_filename()
                        fo = open(fname, 'wb')
                        fw = csv.writer(fo, quotechar=csv_data['del'],
                                delimiter=csv_data['sep'])
                        for (e1, e2, e3) in worker.errors:
                            row = e1
                            row.append(e2)
                            fw.writerow(tuple(row))
                        fo.close()
                    res_win.destroy()
                if worker.exception:
                    common.warning(worker.exception,
                            _('Ocurrio un error XML-RPC!'))
                return False
            elif length >= 0.0 and length <= 1.0:
                pb.set_fraction(length)
            return True
        finally:
            gtk.gdk.threads_leave()
    return progress_callback

    

def progress_window(worker, csv_data, parent):
    pg_win = gtk.Window(type=gtk.WINDOW_TOPLEVEL)
    pg_win.connect('delete-event', stop_import_worker, worker)
    if not parent:
        parent = service.LocalService('gui.main').window
    res_win = gtk.FileChooserDialog(
            _(u'Guardar archivo con registros rechazados'), parent,
            gtk.FILE_CHOOSER_ACTION_SAVE, (gtk.STOCK_CANCEL,
                gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))
    res_win.set_default_response(gtk.RESPONSE_CANCEL)
    vbox = gtk.VBox(False, 0)
    hbox = gtk.HBox(False, 13)
    hbox.set_border_width(10)
    img = gtk.Image()
    img.set_from_stock('gtk-dialog-info', gtk.ICON_SIZE_DIALOG)
    hbox.pack_start(img, expand=True, fill=False)
    vbox2 = gtk.VBox(False, 0)
    label = gtk.Label()
    label.set_markup('<b>' + _(u'Importación en progreso:') + '</b>')
    label.set_alignment(0.0, 0.5)
    vbox2.pack_start(label, expand=True, fill=False)
    vbox2.pack_start(gtk.HSeparator(), expand=True, fill=True)
    vbox2.pack_start(gtk.Label(_(u'Mientras la importación finaliza'
        'puede continuar utilizando el programa')), expand=True, fill=False)
    hbox.pack_start(vbox2, expand=True, fill=True)
    vbox.pack_start(hbox)
    pb = gtk.ProgressBar()
    pb.set_orientation(gtk.PROGRESS_LEFT_TO_RIGHT)
    pb.set_fraction(0.0)
    vbox.pack_start(pb, expand=True, fill=False)
    pg_win.add(vbox)
    pg_win.show_all()
    worker.start()
    pb_callback = gen_progress_callback(pg_win, res_win, csv_data, pb)
    gobject.timeout_add(500, pb_callback, worker)




def new_import_csv(csv_data, f, model, fields, upd_keys, context=None,
        parent=None, win_import=None):
    if not win_import:
        return import_csv(csv_data, f, model, fields, upd_keys,
                context=context, parent=parent, win_import=win_import)
    fname = csv_data['fname']
    content = file(fname,'rb').read()
    input=cStringIO.StringIO(content)
    input.seek(0)
    data = list(csv.reader(input, quotechar=csv_data['del'] or '"',
        delimiter=csv_data['sep']))[int(csv_data['skip']):]
    datas = []
    o2m_flds = []
    for fld in fields:
        flds = fld.split('/')
        if len(flds) > 1:
            o2m_flds.append(fld)
    for line in data:
        if not line:
            continue
        try:
            datas.append(map(lambda x:x.decode(csv_data['combo']).encode('utf-8'),
                line))
        except:
            common.warning('Error UTF-8', 'Importando: %s' % line)
            raise
    if not datas:
        common.warning(_('The file is empty !'), _('Importation !'), parent=parent)
        return False
    dialog = gtk.MessageDialog(parent=win_import.parent, flags=0,
            type=gtk.MESSAGE_QUESTION, buttons=gtk.BUTTONS_YES_NO,
            message_format=u'Utilizar el nuevo método de importación')
    res = dialog.run()
    if res == gtk.RESPONSE_YES:
        dialog.destroy()
        worker = import_worker(datas, import_block, model, f, upd_keys,
                context=context, o2m_fields=o2m_flds)
        progress_window(worker, csv_data, parent)
        win_import.win.destroy()
        return True
    else:
        dialog.destroy()
        win_import.parent.present()
        return import_csv(csv_data, f, model, fields, upd_keys,
                context=context, parent=parent)




#
# TODO: make it works with references
#
def import_csv(csv_data, f, model, fields, upd_keys, context=None, parent=None):
    fname = csv_data['fname']
    content = file(fname,'rb').read()
    input=cStringIO.StringIO(content)
    input.seek(0)
    data = list(csv.reader(input, quotechar=csv_data['del'] or '"', delimiter=csv_data['sep']))[int(csv_data['skip']):]
    datas = []
    for line in data:
        if not line:
            continue
        datas.append(map(lambda x:x.decode(csv_data['combo']).encode('utf-8'), line))
    if not datas:
        common.warning(_('The file is empty !'), _('Importation !'), parent=parent)
        return False
    try:
        res = rpc.session.rpc_exec_auth('/object', 'execute', model, 'import_data', f, datas, 'init', '', False, context, False, upd_keys)
    except Exception, e:
        common.warning(str(e), _('XML-RPC error !'), parent=parent)
        return False
    result = res[0]
    if result>=0:
        if result == 1:
            common.message(_('Imported one object !'))
        else:
            common.message(_('Imported %d objects !') % (result,))
    else:
        d = ''
        for key,val in res[1].items():
            d+= ('\t%s: %s\n' % (str(key),str(val)))
        error = _(u'Error trying to import this record:\n%s\nError Message:\n%s\n\n%s') % (d,res[2],res[3])
        common.message_box(_('Importation Error !'), unicode(error))
    return True

class win_import(object):
    def __init__(self, model, fields, preload = [], parent=None, local_context=None):
        self.glade = glade.XML(common.terp_path("openerp.glade"), 'win_import',
                gettext.textdomain())
        self.glade.get_widget('import_csv_combo').set_active(0)
        self.win = self.glade.get_widget('win_import')
        self.model = model
        self.fields_data = {}
        self.invert = False
        self.context = local_context or {}
        if parent is None:
            parent = service.LocalService('gui.main').window
        self.win.set_transient_for(parent)
        self.win.set_icon(common.OPENERP_ICON)
        self.parent = parent
        self.autodetect_btn = self.glade.get_widget('button_autodetect')
        self.filechooser = self.glade.get_widget('import_csv_file')
        self.filechooser.set_current_folder(
                options.options['client.default_path'])
        self.filechooser.connect('selection-changed',self.file_changed)
        self.view1 = gtk.TreeView()
        self.view1.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
        self.glade.get_widget('import_vp_left').add(self.view1)
        self.view2 = gtk.TreeView()
        self.view2.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
        self.glade.get_widget('import_vp_right').add(self.view2)
        self.view1.set_headers_visible(False)
        self.view2.set_headers_visible(False)

        self.o2m_update = gtk.CheckButton(_('Update O2M Fields'))
        self.o2m_update.set_active(True)
        self.glade.get_widget('vbox44').add(self.o2m_update)

        cell = gtk.CellRendererText()
        column = gtk.TreeViewColumn(_('Field name'), cell, text=0, background=2)
        self.view1.append_column(column)

        cell = gtk.CellRendererToggle()
        cell.set_property('activatable', True)
        cell.connect('toggled', self.sig_toggled_upd)
        column = gtk.TreeViewColumn(_('Update key'), cell, active=2)
        self.view2.append_column(column)

        cell = gtk.CellRendererText()
        column = gtk.TreeViewColumn(_('Field name'), cell, text=0)
        self.view2.append_column(column)

        self.model1 = gtk.TreeStore(gobject.TYPE_STRING, gobject.TYPE_STRING, gobject.TYPE_STRING)
        self.model2 = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING, gobject.TYPE_BOOLEAN)

        for f in preload:
            self.model2.set(self.model2.append(), 0, f[1], 1, f[0], 2, False)

        self.fields = {}
        self.fields_invert = {}
        self.fields_invert2 = {}
        def model_populate(fields, prefix_node='', prefix=None, prefix_value='', level=2):
            fields_order = fields.keys()
            fields_order.sort(lambda x,y: -cmp(fields[x].get('string', ''), fields[y].get('string', '')))
            for field in fields_order:
                if (fields[field].get('type','') not in ('reference',)) \
                        and (not fields[field].get('readonly', False) \
                        or not dict(fields[field].get('states', {}).get(
                            'draft', [('readonly', True)])).get('readonly', True)\
                        or not dict(fields[field].get('states', {}).get(
                            field, [('readonly', True)])).get('readonly', True)):
                    self.fields_data[prefix_node+field] = fields[field]
                    st_name = prefix_value+fields[field]['string'] or field
                    st_name2 = prefix_node + field
                    node = self.model1.insert(prefix, 0, [st_name, prefix_node+field,
                        (fields[field].get('required', False) and '#ddddff') or 'white'])
                    self.fields[prefix_node+field] = st_name
                    self.fields_invert[st_name] = prefix_node+field
                    self.fields_invert2[st_name2] = prefix_node+field
                    if fields[field].get('type','') == 'one2many' and level>0:
                        fields2 = rpc.session.rpc_exec_auth('/object', 'execute', fields[field]['relation'], 'fields_get', False, rpc.session.context)
                        model_populate(fields2, prefix_node+field+'/', node, st_name+'/', level-1)
                    if fields[field].get('relation',False) and level>0:
                        #self.fields[field+':id'] = fields[field]['string']
                        #self.fields_invert[fields[field]['string']] = field+':id'
                        model_populate({'/id':{'string':'ID'},'.id':{'string':_('Database ID')}}, \
                                       prefix_node+field, node, st_name+'/', level-1)
        fields.update({'id':{'string':'ID'},'.id':{'string':_('Database ID')}})
        model_populate(fields)

        #for f in fields:
        #   self.model1.set(self.model1.append(), 1, f, 0, fields[f].get('string', 'unknown'))

        self.view1.set_model(self.model1)
        self.view2.set_model(self.model2)
        self.view1.show_all()
        self.view2.show_all()
        self.o2m_update.show_all()

        self.glade.signal_connect('on_but_unselect_all_clicked', self.sig_unsel_all)
        self.glade.signal_connect('on_but_select_all_clicked', self.sig_sel_all)
        self.glade.signal_connect('on_but_select_clicked', self.sig_sel)
        self.glade.signal_connect('on_but_unselect_clicked', self.sig_unsel)
        self.glade.signal_connect('on_but_autodetect_clicked', self.sig_autodetect)
        
    def file_changed(self, widget=None):
        fname= self.filechooser.get_filename()
        if not fname:
            self.autodetect_btn.set_sensitive(False)
        else:
            self.autodetect_btn.set_sensitive(True)
          
    def sig_autodetect(self, widget=None):
        fname= self.filechooser.get_filename()
        if not fname:
            common.message('You must select an import file first !')
            return True
        csvsep= self.glade.get_widget('import_csv_sep').get_text()
        csvdel= self.glade.get_widget('import_csv_del').get_text()
        csvcode= self.glade.get_widget('import_csv_combo').get_active_text() or 'UTF-8'

        self.glade.get_widget('import_csv_skip').set_value(1)
        try:
            data = csv.reader(file(fname), quotechar=csvdel or '"', delimiter=csvsep)
        except:
            common.warning(_('Error opening .CSV file'), _('Input Error.'), parent=self.win)
            return True
        self.sig_unsel_all()
        word=''
        try:
            for line in data:
                for word in line:
                    word = word.decode(csvcode)
                    word = word.encode('utf-8')
                    #becarefull with unicode and string hashes
                    if (word in self.fields):
                        num = self.model2.append()
                        self.model2.set(num, 0, self.fields[word], 1, word)
                    elif (word.decode('utf-8') in self.fields):
                        num = self.model2.append()
                        self.model2.set(num, 0, self.fields[word.decode('utf-8')], 1, word)
                    elif (word in self.fields_invert or
                            word.decode('utf-8') in self.fields_invert):
                        self.invert = True
                        num = self.model2.append()
                        self.model2.set(num, 0, word, 1, word)
                    elif word in self.fields_invert2:
                        num = self.model2.append()
                        self.model2.set(num, 0, word, 1, self.fields_invert2[word])
                    elif word.decode('utf-8') in self.fields_invert2:
                        num = self.model2.append()
                        self.model2.set(num, 0, word, 1, self.fields_invert2[word.decode('utf-8')])
                    else:
                        raise Exception(_("You cannot import this field %s, because we cannot auto-detect it"))
                break
        except:
            common.warning(_('Error processing your first line of the file.\nField %s is unknown !') % (word,), _('Import Error.'), parent=self.win)
        return True

    def sig_sel_all(self, widget=None):
        self.model2.clear()
        for field in self.fields.keys():
            self.model2.set(self.model2.append(), 0, self.fields[field], 1, field, 2, False)

    def sig_sel(self, widget=None):
        sel = self.view1.get_selection()
        sel.selected_foreach(self._sig_sel_add)

    def _sig_sel_add(self, store, path, iter):
        num = self.model2.append()
        self.model2.set(num, 0, store.get_value(iter,0), 1, store.get_value(iter,1), 2, False)

    def sig_unsel(self, widget=None):
        def _sig_sel_del(store, path, iter):
            store.remove(iter)
        (store,paths) = self.view2.get_selection().get_selected_rows()
        for p in paths:
            store.remove(store.get_iter(p))

    def sig_unsel_all(self, widget=None):
        self.model2.clear()

    def sig_toggled_upd(self, cell, path):
        self.model2[path][2] = not self.model2[path][2]

    def go(self):
        while True:
            button = self.win.run()
            if button == gtk.RESPONSE_OK:
                if not len(self.model2):
                    common.warning(_("You have not selected any fields to import"), parent=self.win)
                    continue

                fields = []
                fields2 = []
                upd_keys = []
                iter = self.model2.get_iter_root()
                while iter:
                    fields.append(self.model2.get_value(iter, 1))
                    fields2.append(self.model2.get_value(iter, 0))
                    if self.model2.get_value(iter, 2):
                        upd_keys.append(fields[-1])
                    iter = self.model2.iter_next(iter)

                csv = {
                    'fname': self.glade.get_widget('import_csv_file').get_filename(),
                    'sep': self.glade.get_widget('import_csv_sep').get_text(),
                    'del': self.glade.get_widget('import_csv_del').get_text(),
                    'skip': self.glade.get_widget('import_csv_skip').get_value(),
                    'combo': self.glade.get_widget('import_csv_combo').get_active_text() or 'UTF-8'
                }
                if self.o2m_update.get_active():
                    self.context['o2m_update'] = True
                #self.parent.present()
                #self.win.destroy()
                if csv['fname']:
                    if self.invert:
                        inverted = []
                        upd_inverted = []
                        for f in fields:
                            for key, value in self.fields_invert.items():
                                if key.encode('utf8') == f:
                                    inverted.append(value)
                                    if f in upd_keys:
                                        upd_inverted.append(value)
                        return new_import_csv(csv, inverted, self.model, self.fields_invert, upd_inverted, context=self.context, parent=self.win, win_import=self)
                    else:
                        return new_import_csv(csv, fields, self.model, self.fields, upd_keys, context=self.context, parent=self.win, win_import=self)
                return False
            else:
                self.parent.present()
                self.win.destroy()
                return False


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

